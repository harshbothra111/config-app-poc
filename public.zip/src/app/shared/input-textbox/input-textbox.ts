import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { FieldDef } from '../../services/product-config.service';
import { buildFieldErrorMessage } from '../../services/validation-utils';

@Component({
  selector: 'input-textbox',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './input-textbox.html',
  styleUrls: ['./input-textbox.scss']
})
export class InputTextbox {
  field = input.required<FieldDef>();
  form = input.required<FormGroup>();
  errorMessage = computed(() => buildFieldErrorMessage(this.field(), this.form().get(this.field().id)));
}
