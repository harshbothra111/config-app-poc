import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { StepDef } from '../../services/product-config.service';
import { InputField } from '../input-field/input-field';

@Component({
  selector: 'form-renderer',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, InputField],
  templateUrl: './form-renderer.html',
  styleUrls: ['./form-renderer.scss']
})
export class FormRenderer {
  step = input<StepDef | undefined>(undefined);
  form = input<any>(null);
}
