import { Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StepDef } from '../../services/product-config.service';

@Component({
  selector: 'app-stepper',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './stepper.html',
  styleUrls: ['./stepper.scss']
})
export class AppStepper {
  steps = input<StepDef[] | null>([]);
  activeIndex = input<number>(0);
  completedIds = input<string[]>([]);
  indexChange = output<number>();

  stepMeta = computed(() => {
    const list = this.steps() || [];
    const active = this.activeIndex();
    const completed = new Set(this.completedIds());
    return list.map((s, i) => ({
      id: s.id,
      canClick: i === active || completed.has(s.id),
      completed: completed.has(s.id),
      active: i === active,
      pending: i !== active && !completed.has(s.id)
    }));
  });

  fillPercent = computed(() => {
    const list = this.steps() || [];
    const len = list.length;
    if (len <= 1) return 0;
    return (this.activeIndex() / (len - 1)) * 100;
  });

  onSelect(i: number) {
    const meta = this.stepMeta()[i];
    if (!meta?.canClick) return;
    this.indexChange.emit(i);
  }
}
