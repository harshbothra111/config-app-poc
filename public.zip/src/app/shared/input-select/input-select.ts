import { Component, input, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { FieldDef, ProductConfigService } from '../../services/product-config.service';
import { buildFieldErrorMessage } from '../../services/validation-utils';
import { Subscription } from 'rxjs';

@Component({
  selector: 'input-select',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './input-select.html',
  styleUrls: ['./input-select.scss']
})
export class InputSelect {
  // Required inputs (avoid nullable checks in template)
  field = input.required<FieldDef>();
  form = input.required<FormGroup>();
  private sub: Subscription | null = null; // retained if needed for manual subscription fallback
  private optionsSig = signal<any[] | null>(null);
  loading = signal(false);

  options = computed(() => this.optionsSig());
  control = computed(() => {
    // Inputs are required, so direct access is safe
    return this.form().get(this.field().id) as FormControl;
  });
  errorMessage = computed(() => buildFieldErrorMessage(this.field(), this.control()));

  constructor(private svc: ProductConfigService) {
    // static options
    effect(() => {
      const f = this.field();
      if (f.options && !f.optionsResource) this.optionsSig.set(f.options);
    });

    // resource without dependency
    effect(() => {
      const f = this.field(); if (!f.optionsResource || f.dependsOn) return;
      this.loading.set(true);
      this.svc.fetchOptions(f.optionsResource).subscribe(opts => { this.optionsSig.set(opts); this.loading.set(false); });
    });

    // resource with dependency
    effect(() => {
      const f = this.field(); const frm = this.form(); if (!f.optionsResource || !f.dependsOn) return;
      const parentCtrl = frm.get(f.dependsOn); if (!parentCtrl) return;
      const val = parentCtrl.value;
      this.optionsSig.set(null);
      if (val == null || val === '') return;
      this.loading.set(true);
      this.svc.fetchOptions(f.optionsResource, { parentValue: val }).subscribe(opts => {
        const cur = frm.get(f.id)?.value;
        if (cur && !opts.includes(cur)) frm.get(f.id)?.setValue(null);
        this.optionsSig.set(opts);
        this.loading.set(false);
      });
    });
  }
}
