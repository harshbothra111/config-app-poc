import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { FieldDef } from '../../services/product-config.service';
import { buildFieldErrorMessage } from '../../services/validation-utils';

@Component({
  selector: 'input-radio',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './input-radio.html',
  styleUrls: ['./input-radio.scss']
})
export class InputRadio {
  field = input.required<FieldDef>();
  form = input.required<FormGroup>();
  errorMessage = computed(() => buildFieldErrorMessage(this.field(), this.form().get(this.field().id)));
}
