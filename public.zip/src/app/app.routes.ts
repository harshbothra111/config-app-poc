import { Routes } from '@angular/router';
import { ProductSelect } from './product/product-select/product-select';

export const routes: Routes = [
	{ path: '', component: ProductSelect },
	{
		path: 'home',
		loadComponent: () => import('./product/home/home-product').then(m => m.HomeProductComponent),
		children: [
			{ path: '', pathMatch: 'full', redirectTo: 'customer-info' },
			{ path: 'customer-info', loadComponent: () => import('./product/home/steps/customer-info/customer-info-step').then(c => c.CustomerInfoStepComponent) },
			{ path: 'coverage', loadComponent: () => import('./product/home/steps/coverage/coverage-step').then(c => c.CoverageStepComponent) },
			{ path: 'summary', loadComponent: () => import('./product/home/steps/summary/summary-step').then(c => c.SummaryStepComponent) },
			{ path: 'quoting', loadComponent: () => import('./product/home/steps/quoting/quoting-step').then(c => c.QuotingStepComponent) },
			{ path: 'rating', loadComponent: () => import('./product/home/steps/rating/rating-step').then(c => c.RatingStepComponent) },
			{ path: 'tenant-details', loadComponent: () => import('./product/home/steps/tenant-details/tenant-details-step').then(c => c.TenantDetailsStepComponent) }
		]
	},
	{
		path: 'auto',
		loadComponent: () => import('./product/auto/auto-product').then(m => m.AutoProductComponent),
		children: [
			{ path: '', pathMatch: 'full', redirectTo: 'customer-info' },
			{ path: 'customer-info', loadComponent: () => import('./product/auto/steps/customer-info/customer-info-step').then(c => c.AutoCustomerInfoStepComponent) },
			{ path: 'coverage', loadComponent: () => import('./product/auto/steps/coverage/coverage-step').then(c => c.AutoCoverageStepComponent) },
			{ path: 'summary', loadComponent: () => import('./product/auto/steps/summary/summary-step').then(c => c.AutoSummaryStepComponent) },
			{ path: 'quoting', loadComponent: () => import('./product/auto/steps/quoting/quoting-step').then(c => c.AutoQuotingStepComponent) },
			{ path: 'rating', loadComponent: () => import('./product/auto/steps/rating/rating-step').then(c => c.AutoRatingStepComponent) },
			{ path: 'rating-summary', loadComponent: () => import('./product/auto/steps/rating-summary/rating-summary-step').then(c => c.AutoRatingSummaryStepComponent) },
			{ path: 'binding', loadComponent: () => import('./product/auto/steps/binding/binding-step').then(c => c.AutoBindingStepComponent) },
			{ path: 'issuance', loadComponent: () => import('./product/auto/steps/issuance/issuance-step').then(c => c.AutoIssuanceStepComponent) }
		]
	}
];
