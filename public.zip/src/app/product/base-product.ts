import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { ProductConfigService, ProductConfig } from '../services/product-config.service';
import { ApiService } from '../services/api.service';
import { ProductPersistenceService } from './models/product-persistence.service';
import { HomeProductModel } from './models/home-product.model';
import { AutoProductModel } from './models/auto-product.model';
import { ProductFlowService } from '../services/product-flow.service';

export abstract class BaseProductComponent {
  protected productId: string;
  productForm!: FormGroup;
  // expose flow service signals via getters to avoid early access before DI init
  get configSignal() { return this.flow.configSignal; }
  get stepIndex() { return this.flow.stepIndex; }
  get completedStepIds() { return this.flow.completedStepIds; }
  get ready() { return this.flow.ready; }
  get currentStep() { return this.flow.currentStep; }
  private initialPath: string | null = null;

  constructor(protected svc: ProductConfigService, protected api: ApiService, protected router: Router, protected route: ActivatedRoute, protected persistence: ProductPersistenceService, protected flow: ProductFlowService, productId: string) {
    this.productId = productId;
    this.captureInitialPath();
    this.loadConfig();
    this.router.events.subscribe(ev => {
      if (ev instanceof NavigationEnd) {
        this.flow.syncIndexFromRoute(this.route);
        this.flow.guardRouteAccess(this.router, this.route);
      }
    });
  }

  protected loadConfig() {
    this.api.get<{ products: Array<{ id: string; endpoint?: string }> }>(`/products/products.json`).subscribe({
      next: registry => {
        const entry = registry.products?.find(p => p.id === this.productId);
        const endpoint = entry?.endpoint;
        const obs = endpoint ? this.svc.getProductConfigFromEndpoint(endpoint) : this.svc.getProductConfig(this.productId);
        obs.subscribe(cfg => {
          this.initCombinedForm(cfg);
          this.flow.init(this.productId, this.productForm, cfg, this.persistence);
          this.restoreModel();
          // recompute conditionals after model restore (field values available now)
          this.flow.recomputeConditionals(this.persistence);
          this.persistModelOnChanges();
          this.flow.syncIndexFromRoute(this.route);
          this.flow.guardRouteAccess(this.router, this.route);
          this.resolveInitialDeepLink();
        });
      },
      error: () => {
          this.svc.getProductConfig(this.productId).subscribe(cfg => {
            this.initCombinedForm(cfg);
            this.flow.init(this.productId, this.productForm, cfg, this.persistence);
            this.restoreModel();
            this.flow.recomputeConditionals(this.persistence);
            this.persistModelOnChanges();
            this.flow.syncIndexFromRoute(this.route);
            this.flow.guardRouteAccess(this.router, this.route);
            this.resolveInitialDeepLink();
          });
      }
    });
  }

  get steps() { return this.configSignal()?.steps || []; }
  totalSteps(): number { return this.configSignal()?.steps?.length ?? 0; }

  protected initCombinedForm(cfg: ProductConfig) { this.productForm = this.svc.createCombinedFormGroup(cfg); }

  onStepperIndex(i: number) { this.flow.setIndex(i, this.router, this.route); }

  next() { this.flow.next(this.router, this.route, this.persistence); }

  prev() { this.flow.prev(this.router, this.route); }

  // conditional logic now fully handled by ProductFlowService
  // navigation helpers handled by ProductFlowService
  // completion persistence & resequencing handled by ProductFlowService

  isStepClickable(i: number): boolean { return this.flow.isStepClickable(i); }

  private restoreModel() {
    if (!this.productForm) return;
    const raw = this.persistence.load<any>(this.productId);
    if (!raw) return;
    switch (this.productId) {
      case 'home': HomeProductModel.applyToForm(HomeProductModel.fromStorage(raw), this.productForm); break;
      case 'auto': AutoProductModel.applyToForm(AutoProductModel.fromStorage(raw), this.productForm); break;
      default: this.productForm.patchValue(raw, { emitEvent: false }); break;
    }
  }

  private buildModel(): any {
    switch (this.productId) {
      case 'home': return HomeProductModel.fromForm(this.productForm);
      case 'auto': return AutoProductModel.fromForm(this.productForm);
      default: return this.productForm.getRawValue();
    }
  }

  private persistModelOnChanges() {
    if (!this.productForm) return;
    this.productForm.valueChanges.subscribe(() => {
      this.persistence.save(this.productId, this.buildModel());
    });
  }

  // initial conditionals handled by flow service during init

  // initial index logic handled by flow service

  private captureInitialPath() {
    const child = this.route.firstChild; if (!child) return;
    const path = child.routeConfig?.path; if (path) this.initialPath = path;
  }

  private resolveInitialDeepLink() {
    if (!this.initialPath) return;
    const cfg = this.configSignal(); if (!cfg) return;
    const targetIdx = cfg.steps.findIndex(st => (st.route || st.id) === this.initialPath);
    if (targetIdx < 0) return; // invalid path
    // gating: ensure targetIdx within next allowed
    let lastCompletedIndex = -1;
    for (let i = 0; i < cfg.steps.length; i++) {
      if (this.completedStepIds().includes(cfg.steps[i].id)) lastCompletedIndex = i;
    }
    const maxAllowed = Math.min(lastCompletedIndex + 1, cfg.steps.length - 1);
    if (targetIdx <= maxAllowed) {
      this.stepIndex.set(targetIdx);
      this.flow.navigate(this.router, this.route);
    }
    this.initialPath = null;
  }

  // recomputeConditionals moved to flow service

  // completion invalidators moved to flow service
}
