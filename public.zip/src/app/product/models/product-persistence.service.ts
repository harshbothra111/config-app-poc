import { Injectable } from '@angular/core';

interface StoredPayload<T> {
  v: number; // schema/version for future migrations
  data: T;
}

@Injectable({ providedIn: 'root' })
export class ProductPersistenceService {
  private version = 1;
  private completedSuffix = 'completedStepIds';

  save<T>(productId: string, model: T): void {
    try {
      const payload: StoredPayload<T> = { v: this.version, data: model };
      sessionStorage.setItem(this.key(productId), JSON.stringify(payload));
    } catch {
      // ignore storage errors
    }
  }

  load<T>(productId: string): T | undefined {
    try {
      const raw = sessionStorage.getItem(this.key(productId));
      if (!raw) return undefined;
      const parsed: StoredPayload<T> = JSON.parse(raw);
      return parsed.data;
    } catch {
      return undefined;
    }
  }

  clear(productId: string): void {
    try { sessionStorage.removeItem(this.key(productId)); } catch { /* ignore */ }
  }

  private key(productId: string): string { return `productModel:${productId}`; }

  private completedKey(productId: string): string { return `${this.completedSuffix}:${productId}`; }

  loadCompleted(productId: string): string[] {
    try {
      const raw = sessionStorage.getItem(this.completedKey(productId));
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.filter(x => typeof x === 'string') : [];
    } catch { return []; }
  }

  saveCompleted(productId: string, list: string[]): void {
    try { sessionStorage.setItem(this.completedKey(productId), JSON.stringify(list)); } catch { /* ignore */ }
  }

  clearAll(): void {
    try {
      const keys: string[] = [];
      for (let i = 0; i < sessionStorage.length; i++) {
        const k = sessionStorage.key(i); if (!k) continue; keys.push(k);
      }
      for (const k of keys) {
        if (k.startsWith('productModel:') || k.startsWith('completedStepIds:')) {
          sessionStorage.removeItem(k);
        }
      }
      // models also exist in localStorage if used there
      const lKeys: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i); if (!k) continue; lKeys.push(k);
      }
      for (const k of lKeys) {
        if (k.startsWith('productModel:')) {
          localStorage.removeItem(k);
        }
      }
    } catch { /* ignore */ }
  }
}
