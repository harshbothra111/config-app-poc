import { FormGroup } from '@angular/forms';

export class AutoProductModel {
  firstName?: string;
  lastName?: string;
  email?: string;
  ssn?: string;
  vehicleYear?: string;
  vehicleMake?: string;
  vehicleModel?: string;
  coverageType?: string;
  bodilyInjuryPerPerson?: number;
  bodilyInjuryPerAccident?: number;
  propertyDamage?: number;
  medicalPayments?: number;
  uninsuredMotorist?: number;
  collisionDeductible?: number;
  comprehensiveDeductible?: number;

  static fromForm(form: FormGroup): AutoProductModel {
    const m = new AutoProductModel();
    Object.assign(m, form.getRawValue());
    return m;
  }

  static applyToForm(model: AutoProductModel, form: FormGroup) {
    if (!model) return;
    form.patchValue(model, { emitEvent: false });
  }

  static fromStorage(raw: any): AutoProductModel {
    if (!raw || typeof raw !== 'object') return new AutoProductModel();
    const m = new AutoProductModel();
    Object.assign(m, raw);
    return m;
  }
}
