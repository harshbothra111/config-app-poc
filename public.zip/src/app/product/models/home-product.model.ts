import { FormGroup } from '@angular/forms';

export class HomeProductModel {
  firstName?: string;
  lastName?: string;
  email?: string;
  ssn?: string;
  ownerType?: string;
  homeValue?: number;
  state?: string;
  city?: string;
  deductible?: number;
  landlordName?: string;
  leaseStart?: string;
  leaseEnd?: string;

  static fromForm(form: FormGroup): HomeProductModel {
    const m = new HomeProductModel();
    Object.assign(m, form.getRawValue());
    return m;
  }

  static applyToForm(model: HomeProductModel, form: FormGroup) {
    if (!model) return;
    form.patchValue(model, { emitEvent: false });
  }

  static fromStorage(raw: any): HomeProductModel {
    if (!raw || typeof raw !== 'object') return new HomeProductModel();
    const m = new HomeProductModel();
    Object.assign(m, raw);
    return m;
  }
}
