import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { HomeProductComponent } from '../../home-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'home-rating-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './rating-step.html',
  styleUrls: ['./rating-step.scss']
})
export class RatingStepComponent {
  private stepId = 'rating';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: HomeProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
