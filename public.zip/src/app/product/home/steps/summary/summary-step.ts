import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { HomeProductComponent } from '../../home-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'home-summary-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './summary-step.html',
  styleUrls: ['./summary-step.scss']
})
export class SummaryStepComponent {
  private stepId = 'summary';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: HomeProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
