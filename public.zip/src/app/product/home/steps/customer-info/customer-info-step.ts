import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { HomeProductComponent } from '../../home-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'home-customer-info-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './customer-info-step.html',
  styleUrls: ['./customer-info-step.scss']
})
export class CustomerInfoStepComponent {
  private stepId = 'customerInfo';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: HomeProductComponent) {}
  next() { this.parent.next(); }
}
