import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { HomeProductComponent } from '../../home-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'home-tenant-details-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './tenant-details-step.html',
  styleUrls: ['./tenant-details-step.scss']
})
export class TenantDetailsStepComponent {
  private stepId = 'tenantDetails';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: HomeProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
