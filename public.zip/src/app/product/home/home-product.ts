import { Component } from '@angular/core';
import { Router, ActivatedRoute, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AppStepper } from '../../shared/stepper/stepper';
import { LoadingSpinner } from '../../shared/loading-spinner/loading-spinner';
import { ProductConfigService } from '../../services/product-config.service';
import { ApiService } from '../../services/api.service';
import { ProductPersistenceService } from '../models/product-persistence.service';
import { BaseProductComponent } from '../base-product';
import { ProductFlowService } from '../../services/product-flow.service';

@Component({
  selector: 'home-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterOutlet, AppStepper, LoadingSpinner],
  templateUrl: './home-product.html',
  styleUrls: ['./home-product.scss']
})
export class HomeProductComponent extends BaseProductComponent {
  constructor(svc: ProductConfigService, api: ApiService, router: Router, route: ActivatedRoute, persistence: ProductPersistenceService, flow: ProductFlowService) {
    super(svc, api, router, route, persistence, flow, 'home');
  }
}
