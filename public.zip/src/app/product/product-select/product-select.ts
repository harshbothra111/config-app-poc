import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ProductPersistenceService } from '../models/product-persistence.service';

interface ProductEntry { id: string; name: string; enabled: boolean; endpoint?: string; }

@Component({
  selector: 'product-select',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-select.html',
  styleUrls: ['./product-select.scss']
})
export class ProductSelect {
  products: ProductEntry[] = [];
  loadError = false;

  constructor(private router: Router, private api: ApiService, private persistence: ProductPersistenceService) {
    this.api.get<{ products: ProductEntry[] }>(`/products/products.json`).subscribe({
      next: resp => { if (resp?.products?.length) this.products = resp.products; },
      error: () => { this.loadError = true; }
    });
  }

  goto(id: string) {
    const prod = this.products.find(p => p.id === id);
    if (!prod || !prod.enabled) return; // guard disabled
    // Clear any previous journey state before starting new product
    this.persistence.clearAll();
    // Navigate to dedicated product component route
    this.router.navigate(['/', id]);
  }
}
