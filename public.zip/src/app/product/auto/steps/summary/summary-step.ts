import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { AutoProductComponent } from '../../auto-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'auto-summary-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './summary-step.html',
  styleUrls: ['./summary-step.scss']
})
export class AutoSummaryStepComponent {
  private stepId = 'summary';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: AutoProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
