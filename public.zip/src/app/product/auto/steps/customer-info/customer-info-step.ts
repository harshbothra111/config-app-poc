import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { AutoProductComponent } from '../../auto-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'auto-customer-info-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './customer-info-step.html',
  styleUrls: ['./customer-info-step.scss']
})
export class AutoCustomerInfoStepComponent {
  private stepId = 'customerInfo';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: AutoProductComponent) {}
  next() { this.parent.next(); }
}
