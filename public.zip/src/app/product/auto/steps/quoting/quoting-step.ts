import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { AutoProductComponent } from '../../auto-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'auto-quoting-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './quoting-step.html',
  styleUrls: ['./quoting-step.scss']
})
export class AutoQuotingStepComponent {
  private stepId = 'quoting';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: AutoProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
