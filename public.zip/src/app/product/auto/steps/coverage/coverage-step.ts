import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormRenderer } from '../../../../shared/form-renderer/form-renderer';
import { AutoProductComponent } from '../../auto-product';
import { StepDef } from '../../../../services/product-config.service';

@Component({
  selector: 'auto-coverage-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormRenderer],
  templateUrl: './coverage-step.html',
  styleUrls: ['./coverage-step.scss']
})
export class AutoCoverageStepComponent {
  private stepId = 'coverage';
  step = computed<StepDef | undefined>(() => this.parent.steps.find(s => s.id === this.stepId));
  constructor(public parent: AutoProductComponent) {}
  prev() { this.parent.prev(); }
  next() { this.parent.next(); }
}
