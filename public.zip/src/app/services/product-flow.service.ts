import { Injectable, signal, computed } from '@angular/core';
import { StepDef, ProductConfig } from '../services/product-config.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { resequenceSteps } from './step-utils';
import { ProductPersistenceService } from '../product/models/product-persistence.service';

@Injectable({ providedIn: 'root' })
export class ProductFlowService {
  productId = '';
  form!: FormGroup;

  configSignal = signal<ProductConfig | null>(null);
  stepIndex = signal(0);
  completedStepIds = signal<string[]>([]);
  readonly insertedConditionalIds = new Set<string>();
  private rawCompletedIds: string[] = [];
  ready = signal(false);

  currentStep = computed(() => {
    const cfg = this.configSignal(); if (!cfg) return null;
    return cfg.steps[this.stepIndex()] || null;
  });

  init(productId: string, form: FormGroup, initialConfig: ProductConfig, persistence: ProductPersistenceService) {
    this.productId = productId;
    this.form = form;
    this.configSignal.set(initialConfig);
    this.rawCompletedIds = persistence.loadCompleted(productId);
    // seed base completions (exclude conditionals until evaluated)
    const baseCompleted = this.rawCompletedIds.filter(id => initialConfig.steps.some(s => s.id === id));
    if (baseCompleted.length) this.completedStepIds.set(baseCompleted);
    // insert any initial conditional steps prior to marking ready
    this.processInitialConditionals(persistence);
    this.ready.set(true);
  }

  finalizeRouteSync(route: ActivatedRoute) {
    // sync index AFTER possible conditional insertion so highlighting matches actual route
    this.syncIndexFromRoute(route);
  }

  private persist(persistence: ProductPersistenceService) {
    persistence.saveCompleted(this.productId, this.completedStepIds());
  }

  markStepCompleted(stepId: string, persistence: ProductPersistenceService) {
    if (!this.completedStepIds().includes(stepId)) {
      this.completedStepIds.update(ids => [...ids, stepId]);
      this.persist(persistence);
    }
  }

  next(router: Router, route: ActivatedRoute, persistence: ProductPersistenceService) {
    const cfg = this.configSignal(); if (!cfg) return;
    const current = cfg.steps[this.stepIndex()]; if (!current) return;
    this.markStepCompleted(current.id, persistence);
    this.processConditionalTransitions(current.id, persistence);
    const after = this.configSignal(); if (!after) return;
    if (this.stepIndex() < after.steps.length - 1) {
      this.stepIndex.set(this.stepIndex() + 1);
      this.navigateToCurrentStep(router, route);
    }
  }

  prev(router: Router, route: ActivatedRoute) {
    if (this.stepIndex() > 0) {
      this.stepIndex.set(this.stepIndex() - 1);
      this.navigateToCurrentStep(router, route);
    }
  }

  setIndex(i: number, router: Router, route: ActivatedRoute) {
    const cfg = this.configSignal(); if (!cfg) return;
    if (i < 0 || i >= cfg.steps.length) return;
    this.stepIndex.set(i);
    this.navigateToCurrentStep(router, route);
  }

  // external alias used by legacy code
  navigate(router: Router, route: ActivatedRoute) {
    this.navigateToCurrentStep(router, route);
  }

  isStepClickable(i: number): boolean {
    const cfg = this.configSignal(); if (!cfg) return false;
    const step = cfg.steps[i]; if (!step) return false;
    return i === this.stepIndex() || this.completedStepIds().includes(step.id);
  }

  navigateToCurrentStep(router: Router, route: ActivatedRoute) {
    const step = this.currentStep(); if (!step) return;
    const seg = step.route || step.id;
    router.navigate([seg], { relativeTo: route });
  }

  syncIndexFromRoute(route: ActivatedRoute) {
    const cfg = this.configSignal(); if (!cfg) return;
    const child = route.firstChild; if (!child) return;
    const path = child.routeConfig?.path; if (!path) return;
    const idx = cfg.steps.findIndex(s => (s.route || s.id) === path);
    if (idx >= 0 && idx !== this.stepIndex()) {
      this.stepIndex.set(idx);
    }
  }

  guardRouteAccess(router: Router, route: ActivatedRoute) {
    const cfg = this.configSignal(); if (!cfg) return;
    const completedIds = this.completedStepIds();
    let lastCompletedIndex = -1;
    for (let i = 0; i < cfg.steps.length; i++) {
      if (completedIds.includes(cfg.steps[i].id)) lastCompletedIndex = i;
    }
    const maxAllowed = Math.min(lastCompletedIndex + 1, cfg.steps.length - 1);
    if (this.stepIndex() > maxAllowed) {
      this.stepIndex.set(maxAllowed);
      this.navigateToCurrentStep(router, route);
    }
  }

  processConditionalTransitions(stepIdCompleted: string, persistence: ProductPersistenceService) {
    const cfg = this.configSignal(); if (!cfg) return;
    const conditionals = cfg.conditionalSteps || [];
    if (!conditionals.length) return;

    let insertedOrRemoved = false;

    for (const c of conditionals) {
      const meta = c.conditional; if (!meta) continue;
      if (meta.insertAfter !== stepIdCompleted) continue;
      const ctrl = this.form.get(meta.control); if (!ctrl) continue;
      const matches = ctrl.value === meta.value;
      const alreadyInserted = this.insertedConditionalIds.has(c.id);

      if (matches && !alreadyInserted) {
        this.insertConditionalStep(c, meta.insertAfter);
        insertedOrRemoved = true;
        if (this.rawCompletedIds.includes(c.id) && !this.completedStepIds().includes(c.id)) {
          this.completedStepIds.update(ids => [...ids, c.id]);
          this.persist(persistence);
        }
      }
      if (!matches && alreadyInserted) {
        this.removeConditionalStep(c.id);
        insertedOrRemoved = true;
      }
    }

    if (insertedOrRemoved) {
      // ensure active index still points to correct route step (do not navigate here)
      // stepIndex stays unless it points beyond array length
      const cfg2 = this.configSignal(); if (cfg2 && this.stepIndex() >= cfg2.steps.length) {
        this.stepIndex.set(cfg2.steps.length - 1);
      }
    }
  }

  processInitialConditionals(persistence: ProductPersistenceService) {
    const cfg = this.configSignal(); if (!cfg) return;
    const conditionals = cfg.conditionalSteps || [];
    const completed = new Set(this.completedStepIds());

    let inserted = false;

    for (const c of conditionals) {
      const meta = c.conditional; if (!meta) continue;
      if (!completed.has(meta.insertAfter)) continue;
      const ctrl = this.form.get(meta.control); if (!ctrl) continue;
      if (ctrl.value === meta.value && !this.insertedConditionalIds.has(c.id)) {
        this.insertConditionalStep(c, meta.insertAfter);
        inserted = true;
        if (this.rawCompletedIds.includes(c.id) && !this.completedStepIds().includes(c.id)) {
          this.completedStepIds.update(ids => [...ids, c.id]);
        }
      }
    }

    if (inserted) {
      this.persist(persistence);
    }
  }

  private insertConditionalStep(step: StepDef, afterId: string) {
    const cfg = this.configSignal(); if (!cfg) return;
    const indexAfter = cfg.steps.findIndex(s => s.id === afterId); if (indexAfter === -1) return;
    if (cfg.steps.some(s => s.id === step.id)) return;
    const newSteps = [...cfg.steps];
    newSteps.splice(indexAfter + 1, 0, step);
    this.configSignal.set({ ...cfg, steps: resequenceSteps(newSteps) });
    for (const f of step.fields) {
      if (!this.form.get(f.id)) {
        this.form.addControl(f.id, new FormControl(null));
      }
    }
    this.insertedConditionalIds.add(step.id);
  }

  private removeConditionalStep(stepId: string) {
    const cfg = this.configSignal(); if (!cfg) return;
    if (!cfg.steps.some(s => s.id === stepId)) return;
    const filtered = cfg.steps.filter(s => s.id !== stepId);
    this.configSignal.set({ ...cfg, steps: resequenceSteps(filtered) });
    const removedStep = cfg.steps.find(s => s.id === stepId);
    if (removedStep) {
      for (const f of removedStep.fields) {
        if (this.form.get(f.id)) this.form.removeControl(f.id);
      }
    }
    this.insertedConditionalIds.delete(stepId);
    if (this.stepIndex() >= filtered.length) this.stepIndex.set(filtered.length - 1);
  }

  // recompute conditionals after form values restored (e.g. deep reload)
  recomputeConditionals(persistence: ProductPersistenceService) {
    const cfg = this.configSignal(); if (!cfg) return;
    const conditionals = cfg.conditionalSteps || [];
    let mutated = false;
    for (const c of conditionals) {
      const meta = c.conditional; if (!meta) continue;
      // only evaluate if base step after which we insert is completed
      if (!this.completedStepIds().includes(meta.insertAfter)) continue;
      const ctrl = this.form.get(meta.control); if (!ctrl) continue;
      const matches = ctrl.value === meta.value;
      const already = this.insertedConditionalIds.has(c.id);
      if (matches && !already) {
        this.insertConditionalStep(c, meta.insertAfter);
        mutated = true;
        if (this.rawCompletedIds.includes(c.id) && !this.completedStepIds().includes(c.id)) {
          this.completedStepIds.update(ids => [...ids, c.id]);
        }
      } else if (!matches && already) {
        this.removeConditionalStep(c.id);
        mutated = true;
      }
    }
    if (mutated) this.persist(persistence);
  }
}
