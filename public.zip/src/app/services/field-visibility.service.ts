import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldDef } from './product-config.service';

@Injectable({ providedIn: 'root' })
export class FieldVisibilityService {
  isVisible(field: FieldDef, form: FormGroup): boolean {
    const cond = field.visibleWhen;
    if (!cond) return true;
    const evalClause = (cl: { control: string; value?: any; predicate?: 'present' | 'equals' }) => {
      const ctrl = form.get(cl.control); if (!ctrl) return false;
      const val = ctrl.value;
      const predicate = cl.predicate || (cl.value === undefined ? 'present' : 'equals');
      return predicate === 'present' ? (val !== null && val !== undefined && val !== '') : val === cl.value;
    };
    let visible = true;
    if (cond.all?.length) visible = cond.all.every(evalClause);
    if (visible && cond.any?.length) visible = cond.any.some(evalClause);
    return visible;
  }

  apply(field: FieldDef, form: FormGroup) {
    const ctrl = form.get(field.id); if (!ctrl) return;
    const show = this.isVisible(field, form);
    if (show && ctrl.disabled) ctrl.enable({ emitEvent: false });
    if (!show && ctrl.enabled) ctrl.disable({ emitEvent: false });
  }
}
