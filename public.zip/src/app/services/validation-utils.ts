import { FieldDef } from './product-config.service';
import { AbstractControl } from '@angular/forms';

export function buildFieldErrorMessage(field: FieldDef, control: AbstractControl | null): string | null {
  if (!control) return null;
  if (!control.touched || control.pending || control.valid) return null;
  const messages = field.validationMessages || {};
  const errors = control.errors || {};
  // async keyed error
  const asyncErr: any = (errors as any)['asyncInvalid'];
  if (asyncErr?.message) return asyncErr.message;
  const priority = ['required','minlength','maxlength','min','max','pattern'];
  for (const k of priority) if (errors[k]) return messages[k] || `${field.label || field.id} is invalid`;
  const first = Object.keys(errors)[0];
  return first ? (messages[first] || `${field.label || field.id} is invalid`) : null;
}
