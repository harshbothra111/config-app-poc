import { StepDef } from './product-config.service';

export function resequenceSteps(steps: StepDef[]): StepDef[] {
  return steps.map((s, i) => ({ ...s, order: i + 1 }));
}
