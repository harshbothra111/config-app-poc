import { Injectable } from '@angular/core';
import { ProductConfigService, ProductConfig, StepDef } from './product-config.service';
import { FormGroup } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

interface ProductState {
  config: ProductConfig;
  forms: Map<string, FormGroup>;
}

@Injectable({ providedIn: 'root' })
export class ProductStateService {
  private state = new Map<string, ProductState>();

  constructor(private cfgSvc: ProductConfigService) {}

  load(productId: string): Observable<ProductConfig> {
    const existing = this.state.get(productId);
    if (existing) return of(existing.config);
    return this.cfgSvc.getProductConfig(productId).pipe(
      tap(cfg => {
        const forms = new Map<string, FormGroup>();
        for (const step of cfg.steps) {
          forms.set(step.id, this.cfgSvc.createFormGroupForStep(step));
        }
        for (const c of cfg.conditionalSteps || []) {
          if (!forms.has(c.id)) forms.set(c.id, this.cfgSvc.createFormGroupForStep(c));
        }
        this.state.set(productId, { config: cfg, forms });
      })
    );
  }

  getConfig(productId: string): ProductConfig | null {
    return this.state.get(productId)?.config || null;
  }

  getForm(productId: string, stepId: string): FormGroup | null {
    return this.state.get(productId)?.forms.get(stepId) || null;
  }

  getStep(productId: string, stepId: string): StepDef | null {
    const cfg = this.getConfig(productId);
    if (!cfg) return null;
    const base = cfg.steps.find(s => s.id === stepId);
    if (base) return base;
    return (cfg.conditionalSteps || []).find(s => s.id === stepId) || null;
  }

  /** Build current ordered step id list including any conditional steps whose conditions pass. */
  getSequence(productId: string): string[] {
    const cfg = this.getConfig(productId);
    if (!cfg) return [];
    const ordered: StepDef[] = [...cfg.steps];
    for (const cStep of cfg.conditionalSteps || []) {
      const cond = cStep.conditional;
      if (!cond) continue;
      const ctrl = this.findControl(productId, cond.control);
      const value = ctrl?.value;
      const shouldInsert = value === cond.value;
      if (shouldInsert) {
        const idx = ordered.findIndex(s => s.id === cond.insertAfter);
        if (idx !== -1 && !ordered.some(s => s.id === cStep.id)) {
          ordered.splice(idx + 1, 0, cStep);
        }
      }
    }
    return ordered.map(s => s.id);
  }

  nextStepId(productId: string, currentStepId: string): string | null {
    const seq = this.getSequence(productId);
    const idx = seq.indexOf(currentStepId);
    if (idx === -1) return null;
    return idx < seq.length - 1 ? seq[idx + 1] : null;
  }

  prevStepId(productId: string, currentStepId: string): string | null {
    const seq = this.getSequence(productId);
    const idx = seq.indexOf(currentStepId);
    if (idx <= 0) return null;
    return seq[idx - 1];
  }

  private findControl(productId: string, controlId: string) {
    const ps = this.state.get(productId);
    if (!ps) return null;
    for (const fg of ps.forms.values()) {
      const c = fg.get(controlId);
      if (c) return c;
    }
    return null;
  }
}
